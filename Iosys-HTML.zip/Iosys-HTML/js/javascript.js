



/***************************** Background Movement ******************************/      


$(document).ready(function() {
  
$('.pth-header .menu-icon').click(function(){

$('.menu-container .pth-top-menu').slideToggle();
})

});




















