<?php

/*
Plugin Name: Iosys Testimonials2
Plugin URI: http://iosys.in/
Description: Easy way to add testimonials in your website
Author: Iosys
Author URI: https://www.iosys.in/
Version: 1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/


function add_ioStyle10971(){
	wp_enqueue_style('stylesheete', plugin_dir_url(__FILE__)."/css/style1.css");
//	wp_enqueue_style('slickCsse', "//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css");
	wp_enqueue_style('font-awee', "//use.fontawesome.com/releases/v5.8.1/css/all.css");
}

add_action('wp_enqueue_scripts', 'add_ioStyle10971');


function add_ioScript10971(){
//	wp_enqueue_script('jquerye','//code.jquery.com/jquery-3.3.1.slim.min.js',null, null, true);
	wp_enqueue_script('slickjse', "//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js", null, null, true);
	wp_enqueue_script('scripte', plugin_dir_url(__FILE__)."/js/script1.js", null , null, true);
}

add_action('wp_enqueue_scripts', 'add_ioScript10971');


class iosysTestimonial10971{
	private static $instance;

	public static function getInstance(){
		if(self::$instance == NULL){
			self::$instance = new self();
		}

		return self::$instance;

	}


	private function __construct(){

		add_action('init', array($this, 'iosys_testimonials10971'));

		add_shortcode('testimonial_ios', array($this, 'iosys_testimonial_shortcode1'));
	}


	public function iosys_testimonials10971(){

		register_post_type('iotestimonialss', array(
				'labels' => array(
					'name' => __("Testimonials"),
					'singular_name' => __("Testimonial"),
				),

				'description' => __("Add Your Testimonials Easily"),
				'supports' => array(
					'title', 'editor', 'excerpt', 'author', 'thumbnail', 'revisions', 'comments', 'custom-fields',),

				'public' => TRUE,
				'menu_icon' => 'dashicons-groups',
				'menu_position' => 20,
				'show_in_nav_menus' => FALSE,
				'taxonomies' => array('category'),

		));

	}


	public function iosys_testimonial_shortcode1($atts){
		ob_start();

		$a = shortcode_atts(array(
		'category' => ''
		), $atts);

		$catShort = $a['category'];
		$testQuery = new WP_query(array(
			'post_type' => 'iotestimonialss',
			'color' => 'blue',
			'order' => 'DESC',
			'orderby' => 'date',
			'category_name' => $catShort,
			'posts_per_page' => 20,
		));

		?>
		<div class="io-pth-testimonials">
		<?php
		if( $testQuery->have_posts() ){?>
			<div class = "io-testimonial-containers">
			<?php while( $testQuery->have_posts() ) : $testQuery->the_post();?>
			<div class = "io-slide-containers">
				<div class = "author-main-div">
					<div class = "author-avatar">
				<?php if (!get_the_post_thumbnail_url() == '' ){?>
				<a href = "<?php $lmeta = get_post_meta(get_the_ID(), 'Link', true);

					echo $lmeta;
						   ?>" target = "_blank"><img  style="width: 180px;" src="<?php echo get_the_post_thumbnail_url(); ?>" /></a><?php }?></div>
					<div class = "author-name-div">
				<span class = "author-name"><?php the_title(); ?> -</span>
				<span class = "author-des"><?php $dmeta = get_post_meta(get_the_ID(), 'Description', true);

					echo $dmeta;
					?></span>
					<span class = "des-auth"><br/><?php $meta = get_post_meta(get_the_ID(), 'Author', true);

					echo $meta;
						?></span></div></div>
				<p><?php the_content(); ?></p>

				</div>
				<?php endwhile; ?>

			</div>
			<?php
				wp_reset_postdata();

				$resultTest = ob_get_clean();
				return $resultTest;
		}
	?>
</div>
<?php

	}

}

iosysTestimonial10971::getInstance();
?>
