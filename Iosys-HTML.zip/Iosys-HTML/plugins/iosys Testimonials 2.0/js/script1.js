jQuery(document).ready(function() {
jQuery(".io-testimonial-containers").slick({
	arrows: true,
	slidesToShow: 3,
    adaptiveHeight: true,
	autoplay: false,
	infinite: true,
	slidesToScroll: 1,
	variableWidth: true,
	prevArrow:"<img class = 'arr-prev' src = '/wp-content/uploads/2019/04/path@3x.png'/>",
    nextArrow:"<img class = 'arr-next' src = '/wp-content/uploads/2019/04/Path.svg'>",
	responsive: [
    		{
      		breakpoint: 1024,
      		settings: {
        		arrows: true,
      			}
    		},

    		{
      		breakpoint: 767,
      		settings: {
        		arrows: false,
				adaptiveHeight: true,
				variableWidth: false,
				slidesToShow:1,
      			}
    		},

    		{
      		breakpoint: 480,
      		settings: {
        		arrows: false,
				adaptiveHeight: true,
				slidesToShow:1,
      			}
    		}

  		]
});
});
